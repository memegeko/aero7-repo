# Aero7 Control Panel icon provenance

All files under `app/` and `pack/` are selected, unmodified PNG assets from
`aerothemeplasma-icons` commit
`96950b8028a5d960cb683280fe5f1d9e33e6b8a2`, the same icon pack pinned by
the Aero7 Pacman repository.

Upstream declares AGPL-3.0-or-later. Its complete license and attribution
notice are included as `pack/UPSTREAM-LICENSE` and
`pack/UPSTREAM-README.md`. The README also records upstream trademark and
original-asset ownership notices; those notices must remain with redistributed
copies. The files were renamed only where an Aero7-namespaced launcher identity
was required. Third-party application and browser-provider icons are not copied
into this directory and remain theme/provider-owned at runtime.
