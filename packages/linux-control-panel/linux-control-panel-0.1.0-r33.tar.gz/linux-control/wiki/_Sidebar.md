## Aero7 Control Panel

- [Home](Home)
- [Control Panel Guide](Control-Panel-Guide)
- [Settings Reference](Settings-Reference)
- [Windows 7 Parity](Windows-7-Parity)
- [Backends and Permissions](Backends-and-Permissions)
- [Installation and Updates](Installation-and-Updates)
- [Screenshots](Screenshots)

## Project

- [Source code](https://github.com/memegeko/aero7-control-panel-)
- [Report a bug](https://github.com/memegeko/aero7-control-panel-/issues)
- [Aero7 website](https://aero7.miku-dayo.com/)
