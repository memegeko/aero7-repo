#include "FirewallPage.h"
#include "ConfFile.h"
#include "IconHelper.h"
#include "Win7Ui.h"
#include "Branding.h"
#include "FirewallStatus.h"

#include <QScrollArea>
#include <QApplication>
#include <QLabel>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QGridLayout>
#include <QFrame>
#include <QFont>
#include <QFile>
#include <QHostInfo>
#include <QComboBox>
#include <QDialog>
#include <QDialogButtonBox>
#include <QDir>
#include <QPushButton>
#include <QInputDialog>
#include <QLineEdit>
#include <QMessageBox>
#include <QProcess>
#include <QStandardPaths>
#include <QSysInfo>

using Win7::ClickableWidget;

namespace {

struct FirewallBackendStatus {
    bool ready = false;
    bool restartRequired = false;
    QString message;
};

// UFW uses the system iptables frontend.  After a kernel package update the
// running kernel can temporarily have no matching modules on disk; nft then
// reports "Protocol not supported" and UFW turns that into the rather opaque
// "Couldn't determine iptables version" error.  Detect that state before an
// authenticated action so the Control Panel can give the user the real fix.
FirewallBackendStatus probeFirewallBackend()
{
    FirewallBackendStatus status;
    const auto selected = Aero7Firewall::backend();
    if (selected == QLatin1String("firewalld")) {
        status.ready = !QStandardPaths::findExecutable(QStringLiteral("firewall-cmd")).isEmpty();
        if (!status.ready)
            status.message = QStringLiteral("The selected firewalld backend is missing. Repair the firewalld package before changing firewall settings.");
        return status;
    }
    if (selected != QLatin1String("ufw")) {
        status.message = QStringLiteral("The selected firewall backend is not recognized. No changes will be made.");
        return status;
    }
    const QString iptables = QStandardPaths::findExecutable(
        QStringLiteral("iptables"));
    if (iptables.isEmpty()) {
        status.message = QStringLiteral(
            "The firewall backend is not installed. Run System Update to "
            "install the required firewall components, then try again.");
        return status;
    }

    QProcess probe;
    probe.start(iptables, {QStringLiteral("-V")});
    if (!probe.waitForStarted(1500) || !probe.waitForFinished(3000)
        || probe.exitStatus() != QProcess::NormalExit
        || probe.exitCode() != 0) {
        const QString runningKernel = QSysInfo::kernelVersion();
        const QDir modulesRoot(QStringLiteral("/usr/lib/modules"));
        const QStringList installedKernels = modulesRoot.entryList(
            QDir::Dirs | QDir::NoDotAndDotDot, QDir::Name);
        const bool runningModulesPresent =
            modulesRoot.exists(runningKernel);

        if (!runningKernel.isEmpty() && !runningModulesPresent
            && !installedKernels.isEmpty()) {
            status.restartRequired = true;
            status.message = QStringLiteral(
                "A system update installed a new Linux kernel, but Aero7 is "
                "still running the previous kernel (%1). Restart Aero7 to "
                "finish the update, then open Linux Firewall again.")
                                 .arg(runningKernel);
            return status;
        }

        QString detail = QString::fromUtf8(probe.readAllStandardError()).trimmed();
        if (detail.isEmpty())
            detail = QString::fromUtf8(probe.readAllStandardOutput()).trimmed();
        status.message = QStringLiteral(
            "The firewall backend could not start. Run System Update, restart "
            "Aero7, and try again.");
        if (!detail.isEmpty())
            status.message += QStringLiteral("\n\nTechnical detail: %1").arg(detail);
        return status;
    }

    status.ready = true;
    return status;
}

QWidget *backendWarning(const FirewallBackendStatus &status)
{
    auto *panel = new QFrame;
    panel->setObjectName(QStringLiteral("firewallBackendWarning"));
    panel->setStyleSheet(
        "#firewallBackendWarning { background: #FFF4CE; border: 1px solid "
        "#D6B656; }"
        "#firewallBackendWarning QLabel { background: transparent; color: "
        "#4A3B00; }");
    auto *layout = new QHBoxLayout(panel);
    layout->setContentsMargins(10, 8, 10, 8);
    layout->setSpacing(8);

    auto *icon = new QLabel;
    icon->setPixmap(themeIcon({"system-reboot", "dialog-warning"}).pixmap(24, 24));
    icon->setFixedSize(24, 24);
    layout->addWidget(icon, 0, Qt::AlignTop);

    auto *text = Win7::bodyLabel(status.message);
    text->setWordWrap(true);
    layout->addWidget(text, 1);
    return panel;
}

} // namespace

// True when the machine has a default route (i.e. is on a network). Mirrors the
// Network and Sharing Center's reading of /proc/net/route: the default route is
// the row whose Destination column ("00000000") is all-zero.
static bool hasDefaultRoute()
{
    QFile f(QStringLiteral("/proc/net/route"));
    if (!f.open(QIODevice::ReadOnly | QIODevice::Text))
        return false;
    const QString text = QString::fromUtf8(f.readAll());
    const QList<QStringView> lines = QStringView(text).split(u'\n');
    for (int i = 1; i < lines.size(); ++i) {           // skip the header row
        const QList<QStringView> cols = lines[i].split(u'\t', Qt::SkipEmptyParts);
        if (cols.size() >= 2 && cols[1].trimmed() == u"00000000")
            return true;
    }
    return false;
}

// Count the `### tuple` rule entries in a ufw user.rules file, one per rule
// the user has added, matching the rule count KDE's firewall module lists.
static int countRules(const QString &path)
{
    QFile f(path);
    if (!f.open(QIODevice::ReadOnly | QIODevice::Text))
        return 0;
    const QString text = QString::fromUtf8(f.readAll());
    int n = 0;
    for (const QStringView &line : QStringView(text).split(u'\n')) {
        if (line.trimmed().startsWith(QLatin1String("### tuple ###")))
            ++n;
    }
    return n;
}

FirewallPage::FwInfo FirewallPage::gatherInfo()
{
    FwInfo fw;
    const auto status = Aero7Firewall::status();
    fw.firewalld = status.backend == QLatin1String("firewalld");
    fw.known = status.known;
    if (fw.firewalld) {
        fw.enabled = status.enabled;
        fw.netConnected = hasDefaultRoute();
        fw.zone = Aero7Firewall::query("firewall-cmd", {"--get-default-zone"});
        fw.logLevel = Aero7Firewall::query("firewall-cmd", {"--get-log-denied"});
        fw.networkName = Aero7Firewall::query("firewall-cmd", {"--get-active-zones"});
        if (fw.networkName.isEmpty())
            fw.networkName = QStringLiteral("No active zone bindings reported");
        // A zone's permanent target is not proof of the current runtime policy.
        fw.inputPolicy = QStringLiteral("ZONE");
        return fw;
    }

    fw.enabled = readConfField(QStringLiteral("/etc/ufw/ufw.conf"),
                           QStringLiteral("ENABLED")).compare(
                               QStringLiteral("yes"), Qt::CaseInsensitive) == 0;
    fw.logLevel = readConfField(QStringLiteral("/etc/ufw/ufw.conf"),
                            QStringLiteral("LOGLEVEL"));

    fw.inputPolicy  = readConfField(QStringLiteral("/etc/default/ufw"),
                                QStringLiteral("DEFAULT_INPUT_POLICY")).toUpper();
    fw.outputPolicy = readConfField(QStringLiteral("/etc/default/ufw"),
                                QStringLiteral("DEFAULT_OUTPUT_POLICY")).toUpper();
    if (fw.inputPolicy.isEmpty())
        fw.inputPolicy = QStringLiteral("DROP");

    fw.ruleCount = countRules(QStringLiteral("/etc/ufw/user.rules"))
                 + countRules(QStringLiteral("/etc/ufw/user6.rules"));

    fw.netConnected = hasDefaultRoute();
    fw.networkName  = QStringLiteral("Network");

    return fw;
}

// Sidebar
QList<SidebarLink> FirewallPage::sidebarLinks()
{
    return {
        Nav::plain("Allow a port or service through Linux Firewall"),
        Nav::to("Change notification settings", PageId::Firewall),
        Nav::plain("Turn Linux Firewall on or off"),
        Nav::plain("Restore defaults"),
        Nav::plain("Advanced settings"),
        Nav::plain("Troubleshoot my network"),
    };
}

QList<SidebarLink> FirewallPage::sidebarSeeAlso()
{
    return {
        Nav::to("Action Center", PageId::ActionCenter),
        Nav::to("Network and Sharing Center", PageId::NetworkSharing),
    };
}

// Network-location panel
// Human-readable phrasing for the default-incoming-policy line, mirroring the
// way KDE's firewall module summarises DEFAULT_INPUT_POLICY.
static QString incomingText(const QString &policy)
{
    if (policy == QLatin1String("ZONE"))
        return QStringLiteral("Controlled separately by each active zone's rules");
    if (policy == QLatin1String("ACCEPT"))
        return QStringLiteral("Allow all incoming connections");
    if (policy == QLatin1String("REJECT"))
        return QStringLiteral("Reject all connections to programs that are not "
                              "on the list of allowed programs");
    // DROP (the ufw default): silently dropped, matching Windows' "Block all".
    return QStringLiteral("Block all connections to programs that are not on "
                          "the list of allowed programs");
}

// Notification/logging phrasing derived from ufw's LOGLEVEL. UFW records
// firewall events; it does not provide interactive per-program approval popups.
static QString notifyText(const QString &logLevel)
{
    if (logLevel.isEmpty())
        return QStringLiteral("Unknown");
    if (logLevel.compare(QLatin1String("off"), Qt::CaseInsensitive) == 0)
        return QStringLiteral("Off");
    QString level = logLevel.toLower();
    level[0] = level[0].toUpper();
    return QStringLiteral("%1 event logging").arg(level);
}

QWidget *FirewallPage::buildLocationPanel(const QString &title,
                                          const QString &connState,
                                          bool expanded,
                                          const FwInfo &info)
{
    auto *panel = new QFrame;
    panel->setObjectName("fwPanel");
    panel->setStyleSheet(
        "#fwPanel { background: #FFFFFF; border: 1px solid #DCDCDC; }");
    auto *panelV = new QVBoxLayout(panel);
    panelV->setContentsMargins(0, 0, 0, 0);
    panelV->setSpacing(0);

    // Header strip: green accent bar, shield icon, title, conn-state, chevron.
    // The header is clickable and toggles the body below, like the Windows
    // firewall network sections.
    auto *header = new ClickableWidget;
    header->setStyleSheet("background: transparent;");
    header->setCursor(Qt::PointingHandCursor);
    auto *headerH = new QHBoxLayout(header);
    headerH->setContentsMargins(0, 0, 8, 0);
    headerH->setSpacing(0);

    auto *accent = new QFrame;
    accent->setFixedWidth(14);
    accent->setMinimumHeight(34);
    accent->setStyleSheet("background: #4E9A2A; border: none;");
    headerH->addWidget(accent);

    auto *shield = new QLabel;
    shield->setFixedSize(20, 20);
    shield->setPixmap(themeIcon({"security-high", "preferences-security-firewall",
                                 "security-medium", "firewall-config"})
                          .pixmap(16, 16));
    shield->setStyleSheet("background: transparent;");
    headerH->addSpacing(8);
    headerH->addWidget(shield, 0, Qt::AlignVCenter);

    headerH->addSpacing(6);
    headerH->addWidget(Win7::label(title, 11, "#1A5FB4"), 0, Qt::AlignVCenter);
    headerH->addStretch(1);

    headerH->addWidget(Win7::label(connState, 11, "#2D2D2D"), 0, Qt::AlignVCenter);

    // The shared round Aero expander. The whole header strip is the click
    // target, so the button itself lets clicks fall through to it.
    auto *chevron = new Win7::ChevronButton(/*interactive=*/false);
    chevron->setChecked(expanded);
    headerH->addSpacing(8);
    headerH->addWidget(chevron, 0, Qt::AlignVCenter);

    header->setMinimumHeight(34);
    panelV->addWidget(header);

    // Body: caption line + the status grid. Built regardless of the initial
    // state so the header can toggle it on click; visibility is set at the end.
    auto *sep = Win7::hairline("#E2E2E2");
    panelV->addWidget(sep);

    // Body has no horizontal margin so the dividers below span the full panel
    // width; the caption and grid carry their own left inset (kLeftInset) so
    // their text lines up under the green banner rather than under the icon.
    const int kLeftInset = 8;
    const int kRightInset = 16;

    auto *body = new QWidget;
    body->setStyleSheet("background: transparent;");
    auto *bodyV = new QVBoxLayout(body);
    bodyV->setContentsMargins(0, 4, 0, 14);
    bodyV->setSpacing(0);

    auto *caption = Win7::bodyLabel(info.firewalld
        ? "Linux Firewall (firewalld) uses network zones. Exceptions apply only "
          "to the zone you select. New connections without an assigned zone use "
          "the default zone."
        :
        "Linux Firewall (ufw) applies one set of rules to every network. Unlike "
        "firewalls with location profiles, it has no separate Home, Work, or "
        "Public rule sets.");
    caption->setContentsMargins(kLeftInset, 0, kRightInset, 0);
    bodyV->addWidget(caption);
    bodyV->addSpacing(12);

    // Divider between the caption and the status grid, as in the Windows panel.
    bodyV->addWidget(Win7::hairline("#E2E2E2"));
    bodyV->addSpacing(14);

    auto *grid = new QGridLayout;
    grid->setContentsMargins(kLeftInset, 0, kRightInset, 0);
    grid->setHorizontalSpacing(55);
    grid->setVerticalSpacing(12);
    grid->setColumnMinimumWidth(0, 200);
    grid->setColumnStretch(1, 1);

    int r = 0;
    grid->addWidget(Win7::bodyLabel(Branding::brand("Linux Firewall state:")),
                    r, 0);
    grid->addWidget(Win7::bodyLabel(!info.known ? "Unavailable — check firewall service"
                                             : info.enabled ? "On" : "Off"), r, 1);
    ++r;

    grid->addWidget(Win7::bodyLabel("Incoming connections:"), r, 0);
    grid->addWidget(Win7::bodyLabel(incomingText(info.inputPolicy)), r, 1);
    ++r;

    grid->addWidget(Win7::bodyLabel("Active networks:"), r, 0);
    // Icon + network-name cell.
    {
        auto *cell = new QWidget;
        cell->setStyleSheet("background: transparent;");
        auto *h = new QHBoxLayout(cell);
        h->setContentsMargins(0, 0, 0, 0);
        h->setSpacing(6);
        auto *icon = new QLabel;
        icon->setFixedSize(16, 16);
        icon->setPixmap(themeIcon({"network-workgroup", "network-type-public",
                                   "preferences-system-network", "network-wired"})
                            .pixmap(16, 16));
        icon->setStyleSheet("background: transparent;");
        h->addWidget(icon, 0, Qt::AlignVCenter);
        h->addWidget(Win7::bodyLabel(info.netConnected ? info.networkName
                                                       : QStringLiteral("None")),
                     0, Qt::AlignVCenter);
        h->addStretch(1);
        grid->addWidget(cell, r, 1, Qt::AlignLeft | Qt::AlignTop);
    }
    ++r;

    grid->addWidget(Win7::bodyLabel("Notification state:"), r, 0);
    grid->addWidget(Win7::bodyLabel(notifyText(info.logLevel)), r, 1);
    ++r;

    bodyV->addLayout(grid);
    panelV->addWidget(body);

    // Dropdown behaviour: clicking the header expands/collapses the body and
    // flips the chevron, matching the Windows firewall network sections.
    auto applyState = [body, sep, chevron](bool open) {
        sep->setVisible(open);
        body->setVisible(open);
        chevron->setChecked(open);
    };
    applyState(expanded);

    // The mutable lambda is stored in header->onClick, so its captured `open`
    // copy persists between clicks and tracks the open/closed state.
    header->onClick = [applyState, open = expanded]() mutable {
        open = !open;
        applyState(open);
    };

    return panel;
}

// Page
FirewallPage::FirewallPage(QScrollArea *sidebar, QWidget *parent)
    : QWidget(parent)
{
    const FwInfo info = gatherInfo();
    const FirewallBackendStatus backend = probeFirewallBackend();

    // Windows 7 lays the content out at a fixed width and leaves the rest of
    // the window blank on the right rather than stretching to fill it.
    auto *contentV = Win7::pageScaffold(this, sidebar, /*bottomMargin=*/20,
                                        /*fixedWidth=*/700);

    contentV->addWidget(
        Win7::pageTitle(Branding::brand(
            "Help protect your computer with Linux Firewall")));
    contentV->addSpacing(10);

    contentV->addWidget(Win7::bodyLabel(Branding::brand(
        "Linux Firewall can help prevent hackers or malicious software from "
        "gaining access to your computer through the Internet or a network.")));
    contentV->addSpacing(10);

    auto addHelpLink = [&](const QString &text) {
        auto *label = Win7::label(text + "  (help article coming later)", 9, "#777777");
        label->setToolTip("This help article is not available yet.");
        contentV->addWidget(label, 0, Qt::AlignLeft);
        contentV->addSpacing(4);
    };
    addHelpLink("How does a firewall help protect my computer?");
    addHelpLink("What are network locations?");

    contentV->addSpacing(12);

    if (!backend.ready) {
        contentV->addWidget(backendWarning(backend));
        contentV->addSpacing(12);
    }

    auto *controls = new QHBoxLayout;
    controls->setSpacing(8);
    auto *toggle = new QPushButton(info.enabled ? "Turn firewall off"
                                                : "Turn firewall on");
    toggle->setObjectName("firewall-toggle");
    toggle->setIcon(themeIcon({"preferences-security-firewall", "security-high"}));
    toggle->setEnabled(backend.ready);
    if (!backend.ready)
        toggle->setToolTip(backend.message);
    connect(toggle, &QPushButton::clicked, this, [this, info]() {
        if (info.firewalld) {
            if (QMessageBox::question(this, "Change firewall state",
                    info.enabled ? "Turn off the firewall? Incoming connections will no longer be filtered by firewalld."
                                 : "Turn on the firewall using its saved zone rules?",
                    QMessageBox::Yes | QMessageBox::No, QMessageBox::No) == QMessageBox::Yes)
                runFirewalld({info.enabled ? "disable" : "enable"},
                    info.enabled ? "The firewall was turned off." : "The firewall was turned on.");
            return;
        }
        const QStringList args = info.enabled
            ? QStringList{"disable"} : QStringList{"--force", "enable"};
        runUfw(args, info.enabled ? "The firewall was turned off."
                                  : "The firewall was turned on.");
    });
    controls->addWidget(toggle);

    auto *allow = new QPushButton("Allow a port or service…");
    allow->setObjectName("firewall-allow-service");
    allow->setEnabled(backend.ready);
    if (!backend.ready)
        allow->setToolTip(backend.message);
    connect(allow, &QPushButton::clicked, this, [this, info]() {
        bool ok = false;
        if (info.firewalld) {
            const QStringList zones = Aero7Firewall::query("firewall-cmd", {"--get-zones"})
                .split(' ', Qt::SkipEmptyParts);
            if (zones.isEmpty()) {
                QMessageBox::warning(this, "Firewall", "No zones could be read. Turn on the firewall and try again.");
                return;
            }
            const QString zone = QInputDialog::getItem(this, "Select firewall zone",
                "Allow the exception only in this zone:", zones,
                qMax(0, zones.indexOf(info.zone)), false, &ok);
            if (!ok)
                return;
            const QString rule = QInputDialog::getText(this, "Allow a port or service",
                "Enter a port/protocol or firewalld service name\n(examples: 22/tcp, 5353/udp, ssh):",
                QLineEdit::Normal, {}, &ok).trimmed();
            if (ok && !rule.isEmpty())
                runFirewalld({"allow", zone, rule}, QStringLiteral("Allowed %1 in zone %2.").arg(rule, zone));
            return;
        }
        const QString rule = QInputDialog::getText(
            this, "Allow a port or service",
            "Enter a port, port/protocol, or installed UFW application profile\n"
            "(examples: 22/tcp, 5353/udp, OpenSSH):",
            QLineEdit::Normal, {}, &ok).trimmed();
        if (ok && !rule.isEmpty())
            runUfw({"allow", rule}, QStringLiteral("Allowed %1.").arg(rule));
    });
    controls->addWidget(allow);

    auto *notifications = new QPushButton("Notification settings…");
    notifications->setObjectName("firewall-notification-settings");
    notifications->setEnabled(backend.ready);
    if (!backend.ready)
        notifications->setToolTip(backend.message);
    connect(notifications, &QPushButton::clicked, this,
            [this, info]() { showNotificationSettings(info.logLevel); });
    controls->addWidget(notifications);

    auto *reset = new QPushButton("Restore defaults…");
    reset->setObjectName("firewall-restore-defaults");
    reset->setEnabled(backend.ready);
    if (!backend.ready)
        reset->setToolTip(backend.message);
    connect(reset, &QPushButton::clicked, this, [this, info]() {
        if (info.firewalld) {
            bool ok = false;
            const QStringList zones = Aero7Firewall::query("firewall-cmd", {"--get-zones"})
                .split(' ', Qt::SkipEmptyParts);
            if (zones.isEmpty()) {
                QMessageBox::warning(this, "Firewall", "Turn on the firewall before restoring zone defaults.");
                return;
            }
            const QString zone = QInputDialog::getItem(this, "Restore zone defaults",
                "Choose the zone to restore:", zones, qMax(0, zones.indexOf(info.zone)), false, &ok);
            if (ok && QMessageBox::warning(this, "Restore firewall defaults",
                    QStringLiteral("Restore the shipped rules for zone %1? Custom rules in this zone will be removed. "
                                   "The firewall will reload its saved configuration, discarding runtime-only changes in all zones. "
                                   "Zones with no shipped defaults cannot be reset. Continue?").arg(zone),
                    QMessageBox::Yes | QMessageBox::No, QMessageBox::No) == QMessageBox::Yes)
                runFirewalld({"reset-zone", zone}, QStringLiteral("Defaults restored for %1.").arg(zone));
            return;
        }
        if (QMessageBox::warning(
                this, "Restore firewall defaults",
                "This removes all custom firewall rules. Continue?",
                QMessageBox::Yes | QMessageBox::No, QMessageBox::No)
            == QMessageBox::Yes) {
            runUfw({"--force", "reset"}, "Firewall defaults were restored.");
        }
    });
    controls->addWidget(reset);
    controls->addStretch(1);
    contentV->addLayout(controls);
    contentV->addSpacing(12);

    if (info.firewalld) {
        auto *location = new QPushButton("Change network location…");
        location->setObjectName("firewall-network-location");
        location->setEnabled(backend.ready && info.enabled);
        contentV->addWidget(location, 0, Qt::AlignLeft);
        connect(location, &QPushButton::clicked, this, [this]() {
            const QStringList active = Aero7Firewall::query("nmcli",
                {"--get-values", "UUID", "connection", "show", "--active"})
                    .split('\n', Qt::SkipEmptyParts);
            QStringList labels, ids;
            for (const QString &uuid : active) {
                const QString type = Aero7Firewall::query("nmcli",
                    {"--get-values", "connection.type", "connection", "show", "uuid", uuid});
                if (type != "802-3-ethernet" && type != "802-11-wireless")
                    continue;
                const QString name = Aero7Firewall::query("nmcli",
                    {"--get-values", "connection.id", "connection", "show", "uuid", uuid});
                labels.append(QStringLiteral("%1 (%2)").arg(name, uuid));
                ids.append(uuid);
            }
            if (ids.isEmpty()) {
                QMessageBox::information(this, "Network location",
                    "Connect to an Ethernet or Wi-Fi network first. Unassigned networks keep the Public default.");
                return;
            }
            bool ok = false;
            const QString selected = QInputDialog::getItem(this, "Network location",
                "Choose the connected network to change:", labels, 0, false, &ok);
            if (!ok)
                return;
            const QString choice = QInputDialog::getItem(this, "Network location",
                "Public blocks unsolicited incoming traffic. Home also permits local mDNS discovery. "
                "Work permits only services you explicitly allow. No choice starts file sharing or remote access.",
                {"Public", "Home", "Work"}, 0, false, &ok);
            if (ok)
                runFirewalld({"profile", ids.at(labels.indexOf(selected)), choice.toLower()},
                             "The location was saved for this connection. Other connections were not changed.");
        });
        contentV->addSpacing(12);
    }

    // The network panel. ufw has no per-network profiles (no Home/Work/Public
    // split), so rather than mimic Windows' two location panels we show a
    // single "All networks" section expanded to the live ufw state. It is
    // "Connected" when a default route exists.
    contentV->addWidget(buildLocationPanel(
        info.firewalld ? "Network zones" : "All networks",
        info.netConnected ? "Connected" : "Not Connected",
        /*expanded=*/true, info));

    contentV->addStretch(1);
}

void FirewallPage::showNotificationSettings(const QString &currentLogLevel)
{
    const bool firewalld = Aero7Firewall::backend() == QLatin1String("firewalld");
    QDialog dialog(this);
    dialog.setWindowTitle("Firewall notification settings");
    dialog.setModal(true);
    dialog.setMinimumWidth(500);

    auto *layout = new QVBoxLayout(&dialog);
    layout->setContentsMargins(18, 16, 18, 14);
    layout->setSpacing(12);

    auto *description = Win7::bodyLabel(
        "The firewall does not show per-program approval popups. These settings control "
        "which firewall events are recorded in the system journal for review "
        "and troubleshooting.");
    description->setWordWrap(true);
    layout->addWidget(description);

    layout->addWidget(Win7::bodyLabel("Firewall event logging:"));

    auto *level = new QComboBox;
    level->setObjectName("firewall-log-level");
    level->addItem("Off — do not record firewall events", "off");
    if (firewalld) {
        level->addItem("Unicast — record denied traffic addressed to this computer", "unicast");
        level->addItem("Broadcast — record denied broadcast traffic", "broadcast");
        level->addItem("Multicast — record denied multicast traffic", "multicast");
        level->addItem("All — record all denied traffic", "all");
    } else {
    level->addItem("Low (recommended) — record important blocked traffic", "low");
    level->addItem("Medium — record additional firewall activity", "medium");
    level->addItem("High — record most traffic with rate limiting", "high");
    level->addItem("Full — record all firewall traffic", "full");
    }
    const QString normalized = currentLogLevel.trimmed().toLower();
    const int current = level->findData(normalized);
    level->setCurrentIndex(current >= 0 ? current : 1);
    layout->addWidget(level);

    auto *warning = Win7::bodyLabel(firewalld
        ? "Logging denied traffic can create substantial journal data. Changing this setting reloads saved firewall rules and discards runtime-only changes."
        :
        "High and Full can create a large amount of journal data. Low is the "
        "recommended setting for normal use.");
    warning->setWordWrap(true);
    layout->addWidget(warning);

    auto *buttons = new QDialogButtonBox(
        QDialogButtonBox::Ok | QDialogButtonBox::Cancel, &dialog);
    connect(buttons, &QDialogButtonBox::accepted, &dialog, &QDialog::accept);
    connect(buttons, &QDialogButtonBox::rejected, &dialog, &QDialog::reject);
    layout->addWidget(buttons);

    if (dialog.exec() != QDialog::Accepted)
        return;

    const QString selected = level->currentData().toString();
    if (selected == normalized)
        return;

    if (firewalld) {
        runFirewalld({"logging", selected}, "Firewall event logging was changed.");
        return;
    }

    runUfw({"logging", selected},
           QStringLiteral("Firewall event logging was changed to %1.")
               .arg(level->currentText().section(QStringLiteral(" — "), 0, 0)));
}

void FirewallPage::runUfw(const QStringList &arguments,
                          const QString &successMessage)
{
    if (QStandardPaths::findExecutable(QStringLiteral("pkexec")).isEmpty()
        || QStandardPaths::findExecutable(QStringLiteral("ufw")).isEmpty()) {
        QMessageBox::warning(
            this, "Firewall",
            "The firewall action requires both pkexec and ufw to be installed.");
        return;
    }
    const FirewallBackendStatus backend = probeFirewallBackend();
    if (!backend.ready) {
        QMessageBox::warning(this,
                             backend.restartRequired ? "Restart required"
                                                     : "Firewall unavailable",
                             backend.message);
        return;
    }
    runAuthenticated("ufw", arguments, successMessage);
}

void FirewallPage::runFirewalld(const QStringList &arguments, const QString &successMessage)
{
    runAuthenticated("/usr/lib/aero7-control-panel/aero7-firewall-helper", arguments, successMessage);
}

void FirewallPage::runAuthenticated(const QString &program, const QStringList &arguments,
                                    const QString &successMessage)
{
    // Application ownership keeps the authenticated operation alive if its
    // settings page is closed. Signals targeting this page disconnect safely.
    auto *process = new QProcess(qApp);
    connect(process, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
            process, &QObject::deleteLater);
    connect(process, &QProcess::errorOccurred, this,
            [this, process](QProcess::ProcessError error) {
        if (error == QProcess::FailedToStart) {
            QMessageBox::warning(this, "Firewall",
                                 "The firewall command could not be started.");
            process->deleteLater();
        }
    });
    connect(process, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
            this, [this, process, successMessage](int code, QProcess::ExitStatus status) {
        const QString error = QString::fromUtf8(process->readAllStandardError()).trimmed();
        if (code == 0 && status == QProcess::NormalExit) {
            QMessageBox::information(this, "Firewall", successMessage);
            emit refreshRequested();
        } else if (code != 126 && code != 127) {
            QMessageBox::warning(this, "Firewall",
                error.isEmpty() ? "The firewall command failed." : error);
        }
        process->deleteLater();
    });
    process->start("pkexec", QStringList{program} + arguments);
}
