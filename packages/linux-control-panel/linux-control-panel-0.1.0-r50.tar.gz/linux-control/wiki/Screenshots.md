# Control Panel Screenshots — 1920×1080

Captured on **5 September 2026** from **linux-control-panel 0.1.0-37**
running in an existing Aero7 QEMU/KVM guest. The guest mode and every PNG are
**1920×1080**, with **100% scale**. These are unmodified framebuffer
captures, not mockups or images enlarged from 1024×768.

This local test package is not a final Beta 2 ISO acceptance result. Read the
[complete capture record](https://github.com/aero7-open-project/aero7/wiki/Screenshot-Capture-Details)
for the exact environment, preparation, and limits.

## Category view

[![Control Panel Home](images/beta2-1080p/control-panel-home.png)](images/beta2-1080p/control-panel-home.png)

Common tasks are grouped by category. The [Control Panel Guide](Control-Panel-Guide)
explains the implemented backends and permission prompts.

## All Control Panel Items

[![All 45 applets in five columns](images/beta2-1080p/control-panel-all-items.png)](images/beta2-1080p/control-panel-all-items.png)

Large icons shows the 45 public applet names in five columns. Several entries
still use repeated generic icons in this captured build. This records the
current mapping rather than claiming exact Windows icon parity.

The [Applet Reference](Applet-Reference) maps all 45 names to actual
destinations. The separate [Settings Reference](Settings-Reference) covers the
71 searchable desktop settings.

## Screen Resolution

[![Display page reporting 1920×1080](images/beta2-1080p/screen-resolution.png)](images/beta2-1080p/screen-resolution.png)

The monitor diagram, selector, resolution, links, and confirmation buttons
use the live virtual monitor's KScreen state. The screenshot does not
establish physical hotplug, mixed-DPI, or mirroring support.

## Turn Aero7 features on or off

[![Optional Features and real state reporting](images/beta2-1080p/optional-features.png)](images/beta2-1080p/optional-features.png)

This retained VM shows real installed, partial, unavailable, and hardware
states. **Programs Center Beta is unavailable here because the older VM lacks
its verified optional-package cache.** The image is not evidence that offline
enable/remove was tested successfully. See [Optional Features](Optional-Features)
for every feature and its requirements.

## Checksums and historical captures

[SHA-256 checksums](images/beta2-1080p/SHA256SUMS.txt) identify these original
images. Older 1024×768 images remain in the source's
[historical screenshot directory](https://github.com/aero7-open-project/aero7-control-panel-/tree/beta/docs/screenshots).
Use [Common Tasks](Common-Tasks) for practical workflows and safe failure
reports; screenshots alone do not certify every backend.
