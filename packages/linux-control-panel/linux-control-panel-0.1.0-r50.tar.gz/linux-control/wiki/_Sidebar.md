## Aero7 Control Panel

- [Home](Home)
- [Control Panel Guide](Control-Panel-Guide)
- [Settings Reference](Settings-Reference)
- [Windows 7 Parity](Windows-7-Parity)
- [All 45 Applets](Applet-Reference)
- [Common Tasks](Common-Tasks)
- [Turn Aero7 features on or off](Optional-Features)
- [Backends and Permissions](Backends-and-Permissions)
- [Installation and Updates](Installation-and-Updates)
- [Screenshots](Screenshots)

## Project

- [Source code](https://github.com/aero7-open-project/aero7-control-panel-)
- [Report a bug](https://github.com/aero7-open-project/aero7-control-panel-/issues)
- [Aero7 website](https://aero7.miku-dayo.com/)
