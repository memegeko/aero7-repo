#pragma once

#include <QHostAddress>
#include <QFile>
#include <QRegularExpression>
#include <QStringList>

namespace Aero7InternetTime {

inline bool validServer(const QString &server)
{
    if (server.isEmpty() || server != server.trimmed() || server.size() > 253)
        return false;
    // QHostAddress accepts arbitrary text after an IPv6 scope separator.
    // This field writes one configuration value, so reject scope suffixes,
    // whitespace and control characters before parsing an address.
    static const QRegularExpression serverCharacters(QStringLiteral("\\A[A-Za-z0-9.:-]+\\z"));
    if (!serverCharacters.match(server).hasMatch())
        return false;
    if (QHostAddress().setAddress(server))
        return true;
    static const QRegularExpression hostname(QStringLiteral(
        "\\A(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)(?:\\."
        "[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*\\.?\\z"));
    return hostname.match(server).hasMatch();
}

// Recover the single server written by this dialog even while timesyncd is
// stopped. Runtime status has no server in that state. Do not treat this as an
// effective-system-config parser: administrators may configure other sources.
inline QString savedServer(const QString &path = QStringLiteral(
    "/etc/systemd/timesyncd.conf.d/10-controlpanel.conf"))
{
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly) || file.size() > 16384)
        return {};
    bool timeSection = false;
    QString server;
    const auto lines = QString::fromUtf8(file.readAll()).split('\n');
    for (const auto &line : lines) {
        const auto trimmed = line.trimmed();
        if (trimmed.startsWith('#') || trimmed.startsWith(';') || trimmed.isEmpty())
            continue;
        if (trimmed.startsWith('[')) {
            timeSection = trimmed == QStringLiteral("[Time]");
            continue;
        }
        const auto equal = trimmed.indexOf('=');
        if (timeSection && equal >= 0 && trimmed.left(equal).trimmed() == QStringLiteral("NTP"))
            server = trimmed.mid(equal + 1).trimmed();
    }
    return validServer(server) ? server : QString();
}

// One authorization and one sequential operation. The server is data in $1,
// never interpolated into shell source or a printf format string.
inline QStringList command(bool enabled, const QString &server)
{
    if (!enabled)
        return {QStringLiteral("/usr/bin/timedatectl"), QStringLiteral("set-ntp"), QStringLiteral("false")};
    if (!validServer(server))
        return {};
    return {QStringLiteral("/bin/sh"), QStringLiteral("-ec"), QStringLiteral(
        "install -d -m 0755 /etc/systemd/timesyncd.conf.d\n"
        "pending=$(mktemp /etc/systemd/timesyncd.conf.d/.aero7-time.XXXXXX)\n"
        "trap 'rm -f -- \"$pending\"' EXIT\n"
        "printf '[Time]\\nNTP=%s\\n' \"$1\" > \"$pending\"\n"
        "chmod 0644 \"$pending\"\n"
        "mv -f -- \"$pending\" /etc/systemd/timesyncd.conf.d/10-controlpanel.conf\n"
        "/usr/bin/timedatectl set-ntp true\n"
        "/usr/bin/systemctl restart systemd-timesyncd.service\n"),
        QStringLiteral("aero7-internet-time"), server};
}

} // namespace Aero7InternetTime
