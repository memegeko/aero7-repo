#pragma once

#include <QFile>
#include <QProcess>
#include <QRegularExpression>
#include <QStandardPaths>

// Shared by the settings page and both Action Center surfaces. Selection is
// read-only: installing firewalld must never migrate an existing UFW user.
namespace Aero7Firewall {
inline QString readFile(const QString &path)
{
    QFile file(path);
    return file.open(QIODevice::ReadOnly)
        ? QString::fromUtf8(file.readAll()).trimmed() : QString();
}

inline QString backend(const QString &root = QString())
{
    const QString marker = readFile(root + QStringLiteral("/etc/aero7/firewall-backend"));
    if (!marker.isEmpty())
        return marker;
    if (QFile::exists(root + QStringLiteral("/etc/ufw/ufw.conf")))
        return QStringLiteral("ufw");
    return QStandardPaths::findExecutable(QStringLiteral("firewall-cmd")).isEmpty()
        ? QStringLiteral("ufw") : QStringLiteral("firewalld");
}

inline QString query(const QString &program, const QStringList &arguments,
                     bool *ok = nullptr)
{
    QProcess process;
    process.start(program, arguments);
    const bool finished = process.waitForFinished(2500);
    const bool success = finished && process.exitStatus() == QProcess::NormalExit
        && process.exitCode() == 0;
    if (!finished) {
        process.kill();
        process.waitForFinished(500);
    }
    if (ok)
        *ok = success;
    return success ? QString::fromUtf8(process.readAllStandardOutput()).trimmed()
                   : QString();
}

struct Status {
    QString backend;
    bool known = false;
    bool enabled = false;
};

inline Status status(const QString &root = QString())
{
    Status result;
    result.backend = backend(root);
    if (result.backend == QLatin1String("firewalld")) {
        bool queried = false;
        const QString state = query(QStringLiteral("systemctl"),
            {QStringLiteral("show"), QStringLiteral("firewalld.service"),
             QStringLiteral("--property=ActiveState"), QStringLiteral("--value")}, &queried);
        if (!queried)
            return result;
        if (state == QLatin1String("active")) {
            // In firewalld 2.5 the Properties.Get used by --state inherits
            // configuration authorization. Polling it can spawn password
            // prompts and lock an account when clients time out. This public
            // information method proves the active daemon responds without
            // requesting permission to modify the firewall.
            const QString zone = query(QStringLiteral("firewall-cmd"),
                {QStringLiteral("--get-default-zone")}, &queried);
            result.known = queried && QRegularExpression(
                QStringLiteral("^[A-Za-z0-9][A-Za-z0-9_-]*$"))
                .match(zone).hasMatch();
            result.enabled = result.known;
        } else {
            result.known = state == QLatin1String("inactive");
        }
    } else if (result.backend == QLatin1String("ufw")) {
        const QString config = readFile(root + QStringLiteral("/etc/ufw/ufw.conf"));
        const auto match = QRegularExpression(QStringLiteral("^ENABLED=(yes|no)$"),
            QRegularExpression::MultilineOption | QRegularExpression::CaseInsensitiveOption).match(config);
        result.known = match.hasMatch();
        result.enabled = result.known && match.captured(1).compare(
            QStringLiteral("yes"), Qt::CaseInsensitive) == 0;
    }
    return result;
}
} // namespace Aero7Firewall
