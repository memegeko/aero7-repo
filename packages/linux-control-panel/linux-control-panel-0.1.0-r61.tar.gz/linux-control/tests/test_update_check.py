import importlib.machinery
import importlib.util
from pathlib import Path
import subprocess
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

ROOT = Path(__file__).resolve().parents[1]
loader = importlib.machinery.SourceFileLoader("update_check", str(ROOT / "helpers/aero7-update-check"))
spec = importlib.util.spec_from_loader(loader.name, loader)
checker = importlib.util.module_from_spec(spec)
loader.exec_module(checker)


class UpdatePolicyTests(unittest.TestCase):
    def preference(self, system=None, user=None):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            if system is not None:
                (root / "system").write_text(system)
            if user is not None:
                (root / "user").write_text(user)
            return checker.checks_enabled(root / "user", root / "system")

    def test_existing_unconfigured_users_not_opted_in(self):
        self.assertFalse(self.preference())

    def test_setup_enabled_preferences(self):
        for preference in ("recommended", "notify"):
            self.assertTrue(self.preference(f"preference={preference}\n"))

    def test_manual_is_off(self):
        self.assertFalse(self.preference("preference=manual\n"))

    def test_user_can_turn_off(self):
        self.assertFalse(self.preference("preference=recommended\n", "[Updates]\nEnabled=false\n"))

    def test_user_can_turn_on(self):
        self.assertTrue(self.preference("preference=manual\n", "[Updates]\nEnabled=true\n"))

    def test_empty_override_is_not_opt_in(self):
        self.assertFalse(self.preference("preference=recommended\n", ""))

    def test_invalid_boolean_fails_closed(self):
        with self.assertRaises(ValueError):
            self.preference("preference=recommended\n", "[Updates]\nEnabled=invalid\n")

    def test_updates_count_and_no_privileged_commands(self):
        run = Mock(return_value=SimpleNamespace(returncode=0, stdout="one 1 -> 2\ntwo 2 -> 3\n"))
        self.assertEqual(checker.probe_updates(Path("/unused/cache"), run), 2)
        self.assertEqual(run.call_args.args[0], ["/usr/bin/checkupdates"])
        env = run.call_args.kwargs["env"]
        self.assertEqual(env["CHECKUPDATES_DB"], "/unused/cache/database")
        self.assertEqual(env["LC_ALL"], "C.UTF-8")

    def test_no_updates_exit_is_not_error(self):
        run = Mock(return_value=SimpleNamespace(returncode=2, stdout=""))
        self.assertEqual(checker.probe_updates(Path("/unused/cache"), run), 0)

    def test_failure_not_reported_as_up_to_date(self):
        for status in (1, 3, -15):
            run = Mock(return_value=SimpleNamespace(returncode=status, stdout=""))
            with self.assertRaises(RuntimeError):
                checker.probe_updates(Path("/unused/cache"), run)

    def test_empty_success_not_misreported(self):
        with self.assertRaises(RuntimeError):
            checker.probe_updates(Path("/unused/cache"), Mock(return_value=SimpleNamespace(returncode=0, stdout="")))

    def test_timeout_not_reported_as_up_to_date(self):
        with self.assertRaises(subprocess.TimeoutExpired):
            checker.probe_updates(Path("/unused/cache"), Mock(side_effect=subprocess.TimeoutExpired("checkupdates", 180)))

    def test_disabled_never_checks_network(self):
        with patch.object(checker.os, "geteuid", return_value=1000), patch.object(checker, "checks_enabled", return_value=False), patch.object(checker, "probe_updates") as probe:
            self.assertEqual(checker.main(), 0)
            probe.assert_not_called()

    def test_root_is_rejected(self):
        with patch.object(checker.os, "geteuid", return_value=0), patch.object(checker, "probe_updates") as probe:
            self.assertEqual(checker.main(), 1)
            probe.assert_not_called()

    def test_gui_requires_confirmation_and_full_upgrade(self):
        source = (ROOT / "src/ui/pages/LinuxUpdatePage.cpp").read_text()
        install = source.split("void LinuxUpdatePage::installUpdates()", 1)[1].split("void LinuxUpdatePage::changeUpdateSettings()", 1)[0]
        self.assertIn("repoPkgs.size() != totalRepo", install)
        self.assertIn("QMessageBox::No) != QMessageBox::Yes", install)
        self.assertLess(install.index("QMessageBox::question"), install.index('m_proc->start("pkexec"'))
        self.assertIn('"-Syu"', install)
        self.assertNotIn('"-Sy"', source)
        self.assertNotIn("m_proc->kill()", install)


if __name__ == "__main__":
    unittest.main()
