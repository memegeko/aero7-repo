#include "LinuxUpdatePage.h"

#include <QApplication>
#include <QCheckBox>
#include <QDialog>
#include <QDialogButtonBox>
#include <QFile>
#include <QLabel>
#include <QMessageBox>
#include <QScopeGuard>
#include <QScrollArea>
#include <QPushButton>
#include <QSettings>
#include <QTemporaryDir>
#include <QTimer>
#include <QtTest>

class UpdateSettingsPageTest : public QObject {
    Q_OBJECT
private slots:
    void updateTransactionSurvivesWindowClose_data()
    {
        QTest::addColumn<bool>("nested");
        QTest::addColumn<bool>("aurOnly");
        QTest::addColumn<bool>("missingCommand");
        QTest::newRow("repository-top-level") << false << false << false;
        QTest::newRow("repository-child-page") << true << false << false;
        QTest::newRow("aur-child-page") << true << true << false;
        QTest::newRow("failed-command-start") << true << false << true;
    }

    void updateTransactionSurvivesWindowClose()
    {
        QFETCH(bool, nested);
        QFETCH(bool, aurOnly);
        QFETCH(bool, missingCommand);
        QTemporaryDir temp;
        QVERIFY(temp.isValid());
        const QByteArray previousPath = qgetenv("PATH");
        const QByteArray previousConfig = qgetenv("XDG_CONFIG_HOME");
        const auto restore = qScopeGuard([&]() {
            qputenv("PATH", previousPath);
            if (previousConfig.isNull()) qunsetenv("XDG_CONFIG_HOME");
            else qputenv("XDG_CONFIG_HOME", previousConfig);
        });
        qputenv("PATH", temp.path().toUtf8());
        qputenv("XDG_CONFIG_HOME", temp.path().toUtf8());
        auto command = [&](const QString &name, const QByteArray &script) {
            QFile file(temp.path() + "/" + name);
            if (!file.open(QIODevice::WriteOnly)) return false;
            file.write("#!/bin/sh\n" + script);
            file.close();
            return file.setPermissions(QFile::ReadOwner | QFile::WriteOwner | QFile::ExeOwner);
        };
        QVERIFY(command("checkupdates", aurOnly ? "exit 2\n" : "echo 'aero7-qa 1 -> 2'\n"));
        QVERIFY(command("yay", aurOnly
            ? "if [ \"$1\" = -Qua ]; then echo 'aero7-qa 1 -> 2'; else exec /bin/sleep 1; fi\n"
            : "exit 1\n"));
        // Never invoke a real privileged/package command. This process only waits.
        if (!missingCommand) QVERIFY(command("pkexec", "exec /bin/sleep 1\n"));
        QWidget owner;
        LinuxUpdatePage page(new QScrollArea, nested ? &owner : nullptr);
        QWidget *window = nested ? &owner : &page;
        window->show();
        page.show();
        page.checkForUpdates();
        auto ready = [&]() {
            for (auto *label : page.findChildren<QLabel *>())
                if (label->text().contains("Install updates for your computer")) return true;
            return false;
        };
        QTRY_VERIFY_WITH_TIMEOUT(ready(), 3000);
        QTimer::singleShot(0, &page, []() {
            auto *question = qobject_cast<QMessageBox *>(QApplication::activeModalWidget());
            QVERIFY(question);
            question->button(QMessageBox::Yes)->click();
        });
        QVERIFY(QMetaObject::invokeMethod(&page, "installUpdates", Qt::DirectConnection));
        QVERIFY(page.isInstallingUpdates());
        bool guidanceFound = false;
        for (auto *label : page.findChildren<QLabel *>()) {
            if (label->text().contains("Please wait for updates to finish")) {
                guidanceFound = true;
                QVERIFY(label->wordWrap());
            }
        }
        QVERIFY(guidanceFound);
        if (!missingCommand) {
            QVERIFY(!window->close());
            QVERIFY(window->isVisible());
        }
        QTRY_VERIFY_WITH_TIMEOUT(!page.isInstallingUpdates(), 2500);
        if (missingCommand) {
            bool found = false;
            for (auto *label : page.findChildren<QLabel *>())
                found |= label->text().contains("Could not start the update command");
            QVERIFY(found);
        }
        QVERIFY(window->close());
    }

    void failedChecksNeverReportUpToDate_data()
    {
        QTest::addColumn<QByteArray>("repo");
        QTest::addColumn<QByteArray>("aur");
        QTest::addColumn<QString>("expected");
        const QString error = "Could not check";
        QTest::newRow("repository-error") << QByteArray("echo network-error >&2\nexit 1\n") << QByteArray("exit 0\n") << error;
        QTest::newRow("repository-crash") << QByteArray("kill -KILL $$\n") << QByteArray("exit 0\n") << error;
        QTest::newRow("empty-repository-success") << QByteArray("exit 0\n") << QByteArray("exit 0\n") << error;
        QTest::newRow("aur-network-error") << QByteArray("exit 2\n") << QByteArray("echo network-error >&2\nexit 1\n") << error;
        QTest::newRow("aur-crash") << QByteArray("exit 2\n") << QByteArray("kill -KILL $$\n") << error;
        QTest::newRow("aur-unreadable") << QByteArray("exit 2\n") << QByteArray("echo invalid-result\nexit 0\n") << error;
        QTest::newRow("no-updates-exit-one") << QByteArray("exit 2\n") << QByteArray("exit 1\n") << QString("is up to date");
        QTest::newRow("no-updates-exit-zero") << QByteArray("exit 2\n") << QByteArray("exit 0\n") << QString("is up to date");
        QTest::newRow("repository-update") << QByteArray("echo 'aero7-qa 1 -> 2'\nexit 0\n") << QByteArray("exit 1\n") << QString("Install updates for your computer");
        QTest::newRow("aur-update") << QByteArray("exit 2\n") << QByteArray("echo 'aero7-qa 1 -> 2'\nexit 0\n") << QString("Install updates for your computer");
        QTest::newRow("missing-yay-is-explicit") << QByteArray("exit 2\n") << QByteArray() << QString("Repository packages are up to date");
    }

    void failedChecksNeverReportUpToDate()
    {
        QFETCH(QByteArray, repo);
        QFETCH(QByteArray, aur);
        QFETCH(QString, expected);
        QTemporaryDir temp;
        QVERIFY(temp.isValid());
        const QByteArray previousPath = qgetenv("PATH");
        const QByteArray previousConfig = qgetenv("XDG_CONFIG_HOME");
        const auto restore = qScopeGuard([&]() {
            qputenv("PATH", previousPath);
            if (previousConfig.isNull()) qunsetenv("XDG_CONFIG_HOME");
            else qputenv("XDG_CONFIG_HOME", previousConfig);
        });
        qputenv("XDG_CONFIG_HOME", temp.path().toUtf8());
        qputenv("PATH", temp.path().toUtf8());
        auto command = [&](const QString &name, const QByteArray &script) {
            QFile file(temp.path() + "/" + name);
            if (!file.open(QIODevice::WriteOnly)) return false;
            file.write("#!/bin/sh\n" + script);
            file.close();
            return file.setPermissions(QFile::ReadOwner | QFile::WriteOwner | QFile::ExeOwner);
        };
        QVERIFY(command("checkupdates", repo));
        if (!aur.isNull()) QVERIFY(command("yay", aur));
        LinuxUpdatePage page(new QScrollArea);
        auto hasText = [&](const QString &text) {
            for (auto *label : page.findChildren<QLabel *>())
                if (label->text().contains(text)) return true;
            return false;
        };
        page.checkForUpdates();
        QTRY_VERIFY_WITH_TIMEOUT(hasText(expected), 3000);
        if (expected == "Could not check") {
            QVERIFY(!hasText("is up to date"));
            QVERIFY(!hasText("There are no available updates"));
        }
    }

    void togglePersistsAndCancelDoesNotChangeIt()
    {
        QTemporaryDir temp;
        QVERIFY(temp.isValid());
        const QByteArray previousPath = qgetenv("PATH");
        const QByteArray previousConfig = qgetenv("XDG_CONFIG_HOME");
        qputenv("XDG_CONFIG_HOME", temp.path().toUtf8());
        qputenv("PATH", temp.path().toUtf8());
        QFile command(temp.path() + "/systemctl");
        QVERIFY(command.open(QIODevice::WriteOnly));
        command.write("#!/bin/sh\nexit 0\n");
        command.close();
        QVERIFY(command.setPermissions(QFile::ReadOwner | QFile::WriteOwner | QFile::ExeOwner));
        LinuxUpdatePage page(new QScrollArea);
        auto edit = [&page](bool enable, bool save) {
            QTimer::singleShot(0, &page, [enable, save]() {
                auto *dialog = qobject_cast<QDialog *>(QApplication::activeModalWidget());
                QVERIFY(dialog);
                auto *check = dialog->findChild<QCheckBox *>("automaticUpdateChecks");
                auto *buttons = dialog->findChild<QDialogButtonBox *>();
                QVERIFY(check);
                QVERIFY(buttons);
                check->setChecked(enable);
                buttons->button(save ? QDialogButtonBox::Save : QDialogButtonBox::Cancel)->click();
            });
            page.changeUpdateSettings();
        };
        const QString path = temp.path() + "/aero7/update-checks.conf";
        edit(true, true);
        QVERIFY(QSettings(path, QSettings::IniFormat).value("Updates/Enabled").toBool());
        edit(false, true);
        QVERIFY(!QSettings(path, QSettings::IniFormat).value("Updates/Enabled").toBool());
        edit(true, false);
        QVERIFY(!QSettings(path, QSettings::IniFormat).value("Updates/Enabled").toBool());
        qputenv("PATH", previousPath);
        if (previousConfig.isNull()) qunsetenv("XDG_CONFIG_HOME");
        else qputenv("XDG_CONFIG_HOME", previousConfig);
    }
};

QTEST_MAIN(UpdateSettingsPageTest)
#include "UpdateSettingsPageTest.moc"
