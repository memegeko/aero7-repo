import importlib.machinery
import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

loader = importlib.machinery.SourceFileLoader("firewall_helper", str(
    Path(__file__).resolve().parents[1] / "helpers/aero7-firewall-helper"))
spec = importlib.util.spec_from_loader(loader.name, loader)
helper = importlib.util.module_from_spec(spec)
loader.exec_module(helper)


class FirewallHelperTest(unittest.TestCase):
    def test_enable_disable_are_persistent_and_immediate(self):
        for action in ("enable", "disable"):
            self.assertEqual(helper.commands([action]), [
                ["/usr/bin/systemctl", action, "--now", "firewalld.service"]])

    def test_port_applies_to_explicit_zone_only(self):
        self.assertEqual(helper.commands(["allow", "aero7-public", "1234/tcp"]), [
            ["/usr/bin/firewall-cmd", "--permanent", "--zone=aero7-public", "--add-port=1234/tcp"],
            ["/usr/bin/firewall-cmd", "--zone=aero7-public", "--add-port=1234/tcp"],
        ])

    def test_service_and_range(self):
        self.assertIn("--add-service=mdns", helper.commands(["allow", "home", "mdns"])[0])
        self.assertIn("--add-port=1000-2000/udp", helper.commands(["allow", "home", "1000-2000/udp"])[0])

    def test_invalid_ports_and_option_injection_rejected(self):
        for value in ("0/tcp", "65536/tcp", "20-10/udp", "22/sctp", "--panic-on",
                      "ssh;id", "ssh\n", "22/tcp --permanent", "$(id)"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                helper.commands(["allow", "home", value])
        with self.assertRaises(ValueError):
            helper.commands(["allow", "--panic-on", "ssh"])

    def test_logging_has_firewalld_levels_only(self):
        for level in ("off", "all", "unicast", "multicast", "broadcast"):
            self.assertEqual(helper.commands(["logging", level]), [
                ["/usr/bin/firewall-cmd", f"--set-log-denied={level}"]])
        with self.assertRaises(ValueError):
            helper.commands(["logging", "low"])

    def test_reset_is_selected_zone_not_global_reset(self):
        self.assertEqual(helper.commands(["reset-zone", "aero7-public"]), [
            ["/usr/bin/firewall-cmd", "--permanent", "--load-zone-defaults=aero7-public"],
            ["/usr/bin/firewall-cmd", "--reload"],
        ])

    def test_unknown_commands_rejected(self):
        for args in ([], ["reset"], ["enable", "ufw"], ["allow", "ssh"]):
            with self.assertRaises(ValueError):
                helper.commands(args)

    def test_profile_is_scoped_to_uuid_and_never_default_zone(self):
        uuid = "00000000-0000-0000-0000-000000000001"
        self.assertEqual(helper.commands(["profile", uuid, "home"]), [
            ["/usr/bin/nmcli", "--wait", "10", "connection", "modify", "uuid", uuid,
             "connection.zone", "aero7-home"]])
        for args in (["profile", "--help", "home"], ["profile", uuid, "trusted"]):
            with self.assertRaises(ValueError):
                helper.commands(args)

    def test_profile_rejects_disconnected_or_virtual_connections_before_change(self):
        import io
        uuid = "00000000-0000-0000-0000-000000000001"
        for responses in ([""], [uuid, "vpn"]):
            with patch.object(helper.os, "geteuid", return_value=0), \
                 patch.object(helper, "check_backend"), \
                 patch("builtins.open", return_value=io.StringIO()), \
                 patch.object(helper.fcntl, "flock"), \
                 patch.object(helper, "run", side_effect=responses) as run:
                with self.assertRaises(ValueError):
                    helper.main(["profile", uuid, "home"])
                self.assertFalse(any("modify" in call.args[0] for call in run.call_args_list))

    def test_no_root_no_operation(self):
        with patch.object(helper.os, "geteuid", return_value=1000), patch.object(helper, "run") as run:
            with self.assertRaises(PermissionError):
                helper.main(["enable"])
            run.assert_not_called()

    def test_legacy_ufw_preserved_even_when_disabled(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = root / "etc/ufw/ufw.conf"
            config.parent.mkdir(parents=True)
            for state in ("yes", "no"):
                config.write_text(f"ENABLED={state}\n")
                with self.assertRaisesRegex(ValueError, "preserved"):
                    helper.check_backend(root)
                self.assertEqual(config.read_text(), f"ENABLED={state}\n")

    def test_explicit_selection_still_rejects_active_ufw(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            marker = root / "etc/aero7/firewall-backend"
            marker.parent.mkdir(parents=True)
            marker.write_text("firewalld\n")
            helper.check_backend(root)
            config = root / "etc/ufw/ufw.conf"
            config.parent.mkdir(parents=True)
            config.write_text("ENABLED=yes\n")
            with self.assertRaisesRegex(ValueError, "competing"):
                helper.check_backend(root)

    def test_command_failure_and_partial_failure_are_reported(self):
        import io
        with patch.object(helper.os, "geteuid", return_value=0), \
             patch.object(helper, "check_backend"), \
             patch("builtins.open", return_value=io.StringIO()), \
             patch.object(helper.fcntl, "flock"), \
             patch.object(helper, "run", side_effect=["", RuntimeError("runtime denied")]):
            with self.assertRaisesRegex(RuntimeError, "permanent setting changed"):
                helper.main(["allow", "home", "ssh"])


if __name__ == "__main__":
    unittest.main()
