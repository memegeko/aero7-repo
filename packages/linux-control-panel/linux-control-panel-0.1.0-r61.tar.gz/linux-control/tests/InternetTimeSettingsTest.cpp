#include "InternetTimeSettings.h"

#include <QDir>
#include <QFile>
#include <QProcess>
#include <QTemporaryDir>
#include <QtTest>

class InternetTimeSettingsTest final : public QObject
{
    Q_OBJECT
private slots:
    void readsSavedServerWithoutRunningTimeService()
    {
        QTemporaryDir root;
        QVERIFY(root.isValid());
        const auto path = root.filePath("10-controlpanel.conf");
        QVERIFY(Aero7InternetTime::savedServer(path).isEmpty());
        const auto check = [&](const QByteArray &contents, const QString &expected) {
            QFile file(path);
            QVERIFY(file.open(QIODevice::WriteOnly | QIODevice::Truncate));
            QCOMPARE(file.write(contents), contents.size());
            file.close();
            QCOMPARE(Aero7InternetTime::savedServer(path), expected);
        };
        check("[Time]\nNTP=time.nist.gov\n", "time.nist.gov");
        check("# ignored\n[Other]\nNTP=wrong.example\n[Time]\n NTP = pool.ntp.org\n", "pool.ntp.org");
        check("[Time]\nNTP=time.nist.gov\n[Other]\nNTP=wrong.example\n", "time.nist.gov");
        check("[Other]\nNTP=wrong.example\n", "");
        check("[Time]\nNTP=time.nist.gov\nNTP=\n", "");
        check("[Time]\nNTP=a.example b.example\n", "");
        check("[Time]\nNTP=$(id)\n", "");
        check("[Time]\nNTP=2001:db8::123\n", "2001:db8::123");
        check(QByteArray(20000, '#'), "");
    }

    void validatesServerData()
    {
        for (const QString &host : {"time.cloudflare.com", "pool.ntp.org", "localhost",
                                   "192.0.2.1", "2001:db8::123", "time.example."})
            QVERIFY2(Aero7InternetTime::validServer(host), qPrintable(host));
        for (const QString &host : {"", "-bad.example", "bad-.example", "a..b",
                                   "a b", "a\nb", "a'b", "$(id)", "a;id", "a/b", "%s",
                                   " time.example", "time.example ",
                                   "fe80::1%x\nNTP=bad.example", "fe80::1%eth0"}) {
            QVERIFY2(!Aero7InternetTime::validServer(host), qPrintable(host));
            QVERIFY(Aero7InternetTime::command(true, host).isEmpty());
        }
        QVERIFY(!Aero7InternetTime::validServer(QString(64, 'a') + ".example"));
    }

    void disablingUsesOneNonShellCommand()
    {
        QCOMPARE(Aero7InternetTime::command(false, "ignored"),
            (QStringList{"/usr/bin/timedatectl", "set-ntp", "false"}));
    }

    void appliesServerBeforeSynchronization_data()
    {
        QTest::addColumn<bool>("failEnable");
        QTest::newRow("success") << false;
        QTest::newRow("enable-failure-stops-before-restart") << true;
    }

    void appliesServerBeforeSynchronization()
    {
        QFETCH(bool, failEnable);
        QTemporaryDir root;
        QVERIFY(root.isValid());
        const auto write = [](const QString &path, const QByteArray &data, bool executable) {
            QFile file(path);
            if (!file.open(QIODevice::WriteOnly) || file.write(data) != data.size())
                return false;
            return !executable || file.setPermissions(QFile::ReadOwner | QFile::WriteOwner | QFile::ExeOwner);
        };
        const auto log = root.path() + "/calls";
        const auto configDir = root.path() + "/config";
        QVERIFY(QDir().mkpath(configDir));
        const auto config = configDir + "/10-controlpanel.conf";
        QVERIFY(write(config, "[Time]\nNTP=old.example\n", false));
        const auto fakeTime = root.path() + "/timedatectl";
        const auto fakeSystem = root.path() + "/systemctl";
        QVERIFY(write(fakeTime, ("#!/bin/sh\n"
            "test \"$(cat '" + config + "')\" = \"$(printf '[Time]\\nNTP=new.example\\n')\" || exit 9\n"
            "printf '%s\\n' \"timedatectl $*\" >> '" + log + "'\n"
            "exit " + (failEnable ? QString("7") : QString("0")) + "\n").toUtf8(), true));
        QVERIFY(write(fakeSystem, ("#!/bin/sh\nprintf '%s\\n' \"systemctl $*\" >> '" + log + "'\n").toUtf8(), true));
        auto command = Aero7InternetTime::command(true, "new.example");
        QCOMPARE(command.size(), 5);
        QVERIFY(!command[2].contains("new.example"));
        QCOMPARE(command.last(), QString("new.example"));
        // Redirect only the test copy into a disposable directory. Production
        // commands retain fixed system paths and never accept a writable root.
        command[2].replace("/etc/systemd/timesyncd.conf.d", configDir);
        command[2].replace("/usr/bin/timedatectl", fakeTime);
        command[2].replace("/usr/bin/systemctl", fakeSystem);
        QProcess process;
        process.start(command.first(), command.mid(1));
        QVERIFY(process.waitForFinished(5000));
        QCOMPARE(process.exitCode(), failEnable ? 7 : 0);
        QFile logFile(log);
        QVERIFY(logFile.open(QIODevice::ReadOnly));
        QCOMPARE(logFile.readAll(), failEnable ? QByteArray("timedatectl set-ntp true\n")
            : QByteArray("timedatectl set-ntp true\nsystemctl restart systemd-timesyncd.service\n"));
        QVERIFY(QDir(configDir).entryList({".aero7-time.*"}, QDir::Files | QDir::Hidden).isEmpty());
    }
};

QTEST_GUILESS_MAIN(InternetTimeSettingsTest)
#include "InternetTimeSettingsTest.moc"
