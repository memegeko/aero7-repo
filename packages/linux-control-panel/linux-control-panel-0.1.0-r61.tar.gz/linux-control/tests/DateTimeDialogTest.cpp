#include "DateTimeDialog.h"
#include "InternetTimeSettings.h"

#include <QApplication>
#include <QCheckBox>
#include <QComboBox>
#include <QFile>
#include <QMessageBox>
#include <QProcess>
#include <QPushButton>
#include <QScopeGuard>
#include <QTemporaryDir>
#include <QTimer>
#include <QtTest>

class DateTimeDialogTest final : public QObject
{
    Q_OBJECT
    static bool writeCommand(const QString &path, const QByteArray &script)
    {
        QFile file(path);
        if (!file.open(QIODevice::WriteOnly) || file.write("#!/bin/sh\n" + script) < 0)
            return false;
        return file.setPermissions(QFile::ReadOwner | QFile::WriteOwner | QFile::ExeOwner);
    }
    static void dismissMessage()
    {
        QTimer::singleShot(0, [] {
            if (auto *box = qobject_cast<QMessageBox *>(QApplication::activeModalWidget()))
                box->accept();
        });
    }
private slots:
    void commandLifetimeAndCancellation()
    {
        QTemporaryDir temp;
        const auto oldPath = qgetenv("PATH");
        const auto oldConfig = qgetenv("XDG_CONFIG_HOME");
        const auto restore = qScopeGuard([&] { qputenv("PATH", oldPath); qputenv("XDG_CONFIG_HOME", oldConfig); });
        qputenv("PATH", temp.path().toUtf8());
        qputenv("XDG_CONFIG_HOME", temp.path().toUtf8());
        QVERIFY(writeCommand(temp.path() + "/timedatectl", "exit 0\n"));
        // No real privileged operation: simulate a delayed cancelled prompt.
        QVERIFY(writeCommand(temp.path() + "/pkexec", "/bin/sleep 0.4\nexit 126\n"));
        DateTimeDialog dialog;
        dialog.show();
        bool done = false;
        QVERIFY(dialog.runPrivileged({"ignored"}, [&] { done = true; }));
        auto *first = dialog.m_privilegedProcess.data();
        QVERIFY(first);
        dismissMessage();
        QVERIFY(!dialog.runPrivileged({"ignored"}, {}));
        QCOMPARE(dialog.m_privilegedProcess.data(), first);
        dismissMessage();
        dialog.reject();
        QVERIFY(dialog.isVisible());
        QTRY_VERIFY(dialog.m_privilegedProcess.isNull());
        QVERIFY(!done);
        dialog.reject();
        QVERIFY(!dialog.isVisible());
    }

    void failedStartReleasesBusyState()
    {
        QTemporaryDir temp;
        const auto oldPath = qgetenv("PATH");
        const auto oldConfig = qgetenv("XDG_CONFIG_HOME");
        const auto restore = qScopeGuard([&] { qputenv("PATH", oldPath); qputenv("XDG_CONFIG_HOME", oldConfig); });
        qputenv("PATH", temp.path().toUtf8());
        qputenv("XDG_CONFIG_HOME", temp.path().toUtf8());
        QVERIFY(writeCommand(temp.path() + "/timedatectl", "exit 0\n"));
        DateTimeDialog dialog;
        bool done = false;
        QTimer dismissal;
        connect(&dismissal, &QTimer::timeout, this, [] {
            if (auto *box = qobject_cast<QMessageBox *>(QApplication::activeModalWidget())) box->accept();
        });
        dismissal.start(10);
        QVERIFY(dialog.runPrivileged({"ignored"}, [&] { done = true; }));
        QTRY_VERIFY(dialog.m_privilegedProcess.isNull());
        QVERIFY(!done);
    }

    void updateNowUsesSelectedServer()
    {
        QTemporaryDir temp;
        const auto oldPath = qgetenv("PATH");
        const auto oldConfig = qgetenv("XDG_CONFIG_HOME");
        const auto restore = qScopeGuard([&] { qputenv("PATH", oldPath); qputenv("XDG_CONFIG_HOME", oldConfig); });
        qputenv("PATH", temp.path().toUtf8());
        qputenv("XDG_CONFIG_HOME", temp.path().toUtf8());
        QVERIFY(writeCommand(temp.path() + "/timedatectl", "printf 'yes\\n'\n"));
        QVERIFY(writeCommand(temp.path() + "/pkexec", "exit 126\n"));
        DateTimeDialog dialog;
        QStringList submitted;
        QTimer::singleShot(0, [&] {
            auto *settings = qobject_cast<QDialog *>(QApplication::activeModalWidget());
            QVERIFY(settings);
            auto *combo = settings->findChild<QComboBox *>();
            QVERIFY(combo);
            combo->setEditText("selected.example");
            QPushButton *update = nullptr;
            for (auto *button : settings->findChildren<QPushButton *>())
                if (button->text() == "Update now") update = button;
            QVERIFY(update);
            update->click();
            QVERIFY(dialog.m_privilegedProcess);
            submitted = dialog.m_privilegedProcess->arguments();
            settings->reject();
        });
        dialog.openInternetSettings();
        QCOMPARE(submitted, Aero7InternetTime::command(true, "selected.example"));
        QTRY_VERIFY(dialog.m_privilegedProcess.isNull());
    }
};

QTEST_MAIN(DateTimeDialogTest)
#include "DateTimeDialogTest.moc"
