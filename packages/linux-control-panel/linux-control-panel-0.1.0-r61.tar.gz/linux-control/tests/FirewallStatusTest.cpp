#include "FirewallStatus.h"
#include <QDir>
#include <QTemporaryDir>
#include <QtTest>

class FirewallStatusTest : public QObject {
    Q_OBJECT
private slots:
    void status_data()
    {
        QTest::addColumn<QString>("marker");
        QTest::addColumn<QString>("ufw");
        QTest::addColumn<QString>("service");
        QTest::addColumn<bool>("probeWorks");
        QTest::addColumn<QString>("backend");
        QTest::addColumn<bool>("known");
        QTest::addColumn<bool>("enabled");
        QTest::newRow("legacy enabled") << "" << "ENABLED=yes" << "inactive" << false << "ufw" << true << true;
        QTest::newRow("legacy disabled") << "" << "ENABLED=no" << "active" << true << "ufw" << true << false;
        QTest::newRow("firewalld active") << "firewalld" << "" << "active" << true << "firewalld" << true << true;
        QTest::newRow("firewalld stopped") << "firewalld" << "" << "inactive" << false << "firewalld" << true << false;
        QTest::newRow("firewalld failed") << "firewalld" << "" << "failed" << false << "firewalld" << false << false;
        QTest::newRow("firewalld query failure") << "firewalld" << "" << "active" << false << "firewalld" << false << false;
        QTest::newRow("unknown backend") << "typo" << "ENABLED=yes" << "active" << true << "typo" << false << false;
    }
    void status()
    {
        QFETCH(QString, marker); QFETCH(QString, ufw); QFETCH(QString, service);
        QFETCH(bool, probeWorks); QFETCH(QString, backend);
        QFETCH(bool, known); QFETCH(bool, enabled);
        QTemporaryDir root;
        QVERIFY(root.isValid());
        const auto write = [&root](const QString &path, const QByteArray &text, bool executable = false) {
            const QString absolute = root.path() + path;
            QDir().mkpath(QFileInfo(absolute).absolutePath());
            QFile file(absolute);
            if (!file.open(QIODevice::WriteOnly) || file.write(text) != text.size())
                return false;
            return !executable || file.setPermissions(QFile::ReadOwner | QFile::WriteOwner | QFile::ExeOwner);
        };
        if (!marker.isEmpty()) QVERIFY(write("/etc/aero7/firewall-backend", marker.toUtf8()));
        if (!ufw.isEmpty()) QVERIFY(write("/etc/ufw/ufw.conf", ufw.toUtf8()));
        QVERIFY(write("/bin/systemctl", "#!/bin/sh\nprintf '%s\\n' '" + service.toUtf8() + "'\n", true));
        QVERIFY(write("/bin/firewall-cmd", probeWorks ? "#!/bin/sh\n[ \"$1\" = --get-default-zone ] || exit 7\nprintf 'aero7-public\\n'\n"
                                                    : "#!/bin/sh\nexit 2\n", true));
        const QByteArray savedPath = qgetenv("PATH");
        qputenv("PATH", (root.path() + "/bin").toUtf8());
        const auto actual = Aero7Firewall::status(root.path());
        qputenv("PATH", savedPath);
        QCOMPARE(actual.backend, backend);
        QCOMPARE(actual.known, known);
        QCOMPARE(actual.enabled, enabled);
    }
};

QTEST_GUILESS_MAIN(FirewallStatusTest)
#include "FirewallStatusTest.moc"
