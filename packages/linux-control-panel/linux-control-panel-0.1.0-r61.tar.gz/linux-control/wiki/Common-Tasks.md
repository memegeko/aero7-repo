# Common Control Panel Tasks

## Find the right page

Start with **Control Panel** in Start. Category view groups related tasks;
**View by > Large icons** shows the 45 familiar entry points in five columns.
Use Search Control Panel when you know a Windows or KDE setting name. The
[Settings Reference](Settings-Reference) covers the 71 searchable desktop
settings, while [Applet Reference](Applet-Reference) covers the 45 entry
points. These are different inventories, not contradictory totals.

## Change screen resolution

Open **Display > Screen resolution**, or right-click the desktop and choose
**Screen resolution**. Select the correct monitor before changing its
resolution. The display diagram, monitor selection, resolution controls,
orientation, and apply/confirmation flow use live KScreen information.

Choose a mode actually offered by the display, and consider scale separately.
For the documentation VM, the mode is **1920×1080**, scale **100%**. Apply the
change, inspect the result, and confirm it only when the display is usable.
Allow the timed rollback if the result is unreadable. Do not treat a virtual
monitor's mode list as the supported modes of a physical laptop.

Multiple outputs add positioning, primary-output, enable/disable, and scaling
choices. Mirroring and physical mixed-DPI/hotplug behavior are not certified
by a single-screen screenshot. See the
[desktop display guide](https://github.com/aero7-open-project/aero7-desktop/wiki/Displays-and-Multi-Monitor).

## Turn Aero7 features on or off

Search Start for the exact name **Turn Aero7 features on or off**, or use the
link in Programs and Features. Select a feature and read its description,
status, required packages, and service/hardware requirements. Review the
change plan, approve the administrator prompt, and wait for final verification.

Programs Center Beta is optional; disabling it must not remove Desktop Core.
Beta 2's install path retains its verified package for offline re-enabling.
Other optional repository features generally need internet when first added.
Do not interpret "offline installation" as "every later optional feature can
be downloaded without internet." See [Optional Features](Optional-Features)
for all entries and unavailable equivalents.

## Update the system

Open **Windows Update**. The familiar page checks Aero7/Arch repositories and
uses pacman, not Microsoft Update. Review the offered transaction and approve
the administrator prompt. Use one package manager at a time, allow downloads
and configuration to finish, and save work before a requested restart.

The offline ISO removes the need to download the base install package set.
Later repository updates still require a connection. If a download fails,
save the full error and repository/package name; do not disable signatures.

### Optional automatic checking (Beta 2 candidate)

Use **Change settings** to enable or disable automatic update checks, then save.
This preference controls checking and notifications only. Updates still require
your review and approval before installation; there is no unattended-install
mode. Disabling checks does not stop an installation you already approved.
An offline or failed check cannot establish whether updates are available.

The on/off preference has been tested in an upgraded disconnected VM. Positive
update notifications and the final-image install-approval path remain under QA;
these local candidate changes are not a claim of public package availability.

## Choose a network location (Beta 2 candidate)

Fresh installations use firewalld. Existing UFW configurations are retained,
including configurations where UFW is disabled; installing this Control Panel
does not migrate them. The Firewall page identifies the selected backend and
reports unavailable status separately from a confirmed disabled firewall.

On firewalld, use **Change network location** to select an active wired or Wi-Fi
connection, then choose Public, Home or Work and authenticate. The choice is
saved for that NetworkManager connection, not every network. Public remains the
fallback. Home permits local mDNS discovery; it does not start file-sharing or
remote-access services. Work also blocks unsolicited access unless you approve
an exception. Choose Public when unsure. Offline or ambiguous first-run choices
keep Public until you select a connected network later.

Rules and service exceptions are zone-specific. Read the displayed warning
before restoring zone defaults or changing logging: a firewall reload can
discard unrelated runtime-only rules. These new profile controls pass local
tests; fresh-install packet and reboot acceptance is still pending.

## Remove or repair a program

**Programs and Features** shows installed software. Select the intended item,
review the proposed action and dependencies, then confirm and authenticate.
Core desktop, boot, kernel, and package-management components are protected.
For a service installed through Optional Features, use its feature toggle so
package and service handling stay together.

Removing an application is not the same as deleting its documents, and an
application's settings can remain for reinstallation. Read the transaction
before accepting it. A dependency error is a stopped operation, not proof the
application was removed.

## Report a failure

Include the page or feature name, steps, expected result, actual result,
complete error text, installed package version, online/offline state, and
whether authentication was accepted. Add hardware details for device-specific
failures. Review logs and screenshots for private information before sharing.

Native editors own the Aero7 dialog but use Linux/Plasma configuration and
services underneath. "Native" does not mean every historical Windows option
has an equivalent; [Applet Reference](Applet-Reference) states those limits.
