# Aero7 Gadgets icon provenance

`app/aero7-gadget-gallery.png`, the native-size files below `app/*/`, and
`toolbar/online.png` are unmodified copies of `gadgets.png` and
`internet-web-browser.png` from
`aerothemeplasma-icons` commit
`96950b8028a5d960cb683280fe5f1d9e33e6b8a2`. They are renamed only to provide
stable Aero7 resource and launcher identities.

Upstream declares AGPL-3.0-or-later. The package license and README attribution
must be installed alongside these assets.
